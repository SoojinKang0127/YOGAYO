const squares = document.querySelector(".squares")
for (var i = 1; i < 78; i++) {
  const level = Math.floor(Math.random() * 3)
  squares.insertAdjacentHTML("beforeend", `<li data-level="${level}"></li>`)
}
